// angular.module('phonecatApp', ['phoneList']);
angular.module('phonecatApp', [
    // ...which depends on the `phoneList` module
    'phoneList'
]);